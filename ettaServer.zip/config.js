module.exports = {
	"secret": "yourtutorialsucks"
}
